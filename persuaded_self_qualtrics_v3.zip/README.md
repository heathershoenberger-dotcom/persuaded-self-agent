# Persuaded Self — experimental shopping agent v3

## Design
2 × 2 between-subjects: `agent_role` = `collab` or `functional`; `sponsor_status` = `yes` or `no`.
Everyone makes their own final choice, including rejecting the recommendation. All three fictional products cost $129. The recommendation is the same within an assigned `agent_target` brand, and the disclosure is explicit in both sponsorship conditions. Product information is fixed; the agent is scripted, not a live LLM.

**IMPORTANT research limitation:** This is a prototype. The collaborative arm currently includes additional reflective/elaboration questions compared with the functional arm, so it manipulates elaboration as well as interaction style and has more clicks/time-on-task. This may be useful if you intend to test *co-construction*, but it does NOT isolate relational framing alone. Pilot and consider matched-turn variants. Product feature priority does not algorithmically determine the recommendation; the recommendation is randomized/assigned and may not align with stated priorities. The independent condition says no manufacturer paid for promotion; do not imply this is a factual independent evaluation of optimal product fit.

## Publish on GitHub Pages
1. Open your existing `persuaded-self-agent` GitHub repository.
2. Replace its root `index.html` with this package's `index.html` (GitHub: open file → pencil/Edit → paste contents → Commit changes, or upload replacement).
3. Settings → Pages → Deploy from branch → `main` / root. Wait for site to deploy.
4. Test these examples (replace YOUR-GITHUB-USERNAME):
   - `https://YOUR-GITHUB-USERNAME.github.io/persuaded-self-agent/?role=collab&sponsor=yes&target=Auralis%20One`
   - `https://YOUR-GITHUB-USERNAME.github.io/persuaded-self-agent/?role=collab&sponsor=no&target=Auralis%20One`
   - `https://YOUR-GITHUB-USERNAME.github.io/persuaded-self-agent/?role=functional&sponsor=yes&target=Auralis%20One`
   - `https://YOUR-GITHUB-USERNAME.github.io/persuaded-self-agent/?role=functional&sponsor=no&target=Auralis%20One`

## Qualtrics Survey Flow
Create an Embedded Data element **before** the agent question, defining:
`agent_role`, `sponsor_status`, `agent_target`, `agent_complete`, `agent_code`, `agent_initial`, `agent_initial_certainty`, `agent_pref1`, `agent_pref2`, `agent_pref3`, `agent_elaboration`, `agent_selected`, `agent_accepted`.

Add a Randomizer that evenly presents one of four branches. In each branch, set the following embedded data:
- Branch 1: `agent_role=collab`, `sponsor_status=yes`
- Branch 2: `agent_role=collab`, `sponsor_status=no`
- Branch 3: `agent_role=functional`, `sponsor_status=yes`
- Branch 4: `agent_role=functional`, `sponsor_status=no`

For a first pilot, set `agent_target=Auralis One` for everyone. For the full study, counterbalance recommended brands separately, using a second randomizer or a balanced 12-cell allocation (2 × 2 × 3) to avoid brand confounds. **Do not let an additional randomizer overwrite the role/sponsor values.**

## Embed
1. Add a Text/Graphic question after the randomizer.
2. In HTML view, paste `qualtrics_embed.html`.
3. Use that question's **Add JavaScript** editor to paste `qualtrics_question_js.txt`. Replace YOUR-GITHUB-USERNAME with your actual account name.
4. Preview all four conditions and check Embedded Data in test responses. Some Qualtrics licenses/security settings may restrict iframes or custom JS. A direct external-link workflow requires a different return/verification method; don't assume a link alone writes data back to Qualtrics.
5. After this question, place validated/pretested survey items for perceived preference self-authorship, decision ownership, identity incorporation, AI influence, sponsorship recognition, and persuasion knowledge. The agent deliberately does not ask these outcomes to avoid priming.

## Research checks
- The initial preference task exposes product facts before interaction and is logged. This may make source attribution salient.
- Distinguish the consumer's *choice* from perceived self-authorship. Some may reject the recommended brand; analyze all randomized participants (intent-to-treat) and do not exclude rejecters post hoc.
- If you want a clean test of relational *framing* alone, make collaborative and functional arms match in question count, response options, time, and elaboration.
- For source-monitoring, introduce uniquely AI-originated vs participant-originated claims and log their provenance; the present prototype does not test objective cryptomnesia.
- The iframe completion message is origin-checked by Qualtrics. It is not a high-security identity/authentication mechanism. Avoid transmitting personal identifiers or sensitive data. The completion code is for troubleshooting, not anti-fraud validation.
- Consent, IRB approval, pilot checks, and debriefing are the researcher's responsibility. No real purchase occurs.
